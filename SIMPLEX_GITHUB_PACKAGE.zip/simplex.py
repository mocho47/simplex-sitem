# Código Python del sistema SIMPLEX
print('SIMPLEX listo')