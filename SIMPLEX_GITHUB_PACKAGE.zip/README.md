# SIMPLEX
Sistema automatizado con manifiesto, voz e interfaz para negocios.